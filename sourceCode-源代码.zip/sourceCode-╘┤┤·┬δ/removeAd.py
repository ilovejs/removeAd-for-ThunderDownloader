import os, stat
import tempfile
import shutil

tempdir = tempfile.gettempdir() # prints the current temporary directory
tempdir += "\Thunder Network\Thunder"
#remove folder with content in it
shutil.rmtree(tempdir)

#create a file name "Thunder"
file = open(tempdir, 'w+')
str = "This is the end"
file.write( str )
file.close()

#make that file readonly
myFile = tempdir
fileAtt = os.stat(myFile)[0]
if (not fileAtt & stat.S_IWRITE):
    # File is read-only, so make it writeable
    os.chmod(myFile, stat.S_IWRITE)
else:
#    if(fileAtt || !stat.S_IWRITE):
    # File is writeable, so make it read-only
    os.chmod(myFile, stat.S_IREAD)