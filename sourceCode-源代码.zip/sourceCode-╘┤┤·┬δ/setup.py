from distutils.core import setup
import py2exe
setup(
    console = [
            {
            "script": "removeAd.py",                    ### Main Python script
            "icon_resources": [(0, "christmas-cookie-tree.ico")]     ### Icon to embed into the PE file.
        }
    ],
)